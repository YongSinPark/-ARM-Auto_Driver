/*
 * RC_CAR.c
 *
 * Created: 2022-08-18 오전 9:48:44
 * Author : kccistc
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h> 
#include <avr/interrupt.h>
#include <stdio.h>
#include <string.h>
#include "uart1.h"
#include "ultrasonic.h"

extern void UART0_transmit(uint8_t data);
extern void pc_command_processing();
extern void init_UART1();


FILE OUTPUT = FDEV_SETUP_STREAM(UART0_transmit, NULL, _FDEV_SETUP_WRITE);

uint32_t ms_count=0;  // ms를 재는 변수
uint32_t sec_count=0;  // sec를 재는 변수

extern volatile uint8_t rx_ready_flag; // 완전한 문장이 들어왔을 때 1로 set 된다
void init_pwm_motor();
void init_timer0();
// 1. 분주: 64분주 ==> 16000000/64 ==> 250,000HZ
// 2. T 계산 ==> 1/f = 1/250000 = > 0.000004 sec (4us) : 0.004ms
// 3. 8 bit Timer OV: 0.004ms x 256 ==> 0.00124sec ==> 약 1.24ms
//                    0.004ms x 250 ==> 1ms
// 256개의 pulse를 count를 하면 이곳으로 온다.
// 1ms 마다 ISR(TIMER0_OVF_vect) 이곳으로 들어 온다
ISR(TIMER0_OVF_vect)
{
   TCNT0 = 6;
   
   ms_count++;
   if (ms_count >= 1000)   // 1000ms ==> 1sec
   {
      ms_count=0;
      sec_count++;    // sec counter증가    
   }
}

int main(void)
{  
	PORTA = 0XFF;
	PORTG = 0x00;
	PORTF = 0x00;
	init_led();
	init_button();
	init_uart0();  // uart0 초기화
	init_UART1();  // uart1 초기화
	init_pwm_motor();
	init_ultrasonic();
	stdout = &OUTPUT; // stdout : 출력
   
	init_timer0();
	sei();         // 전역적으로 인터럽트 허용

	while (1) 
	{
		manual_mode_run(); // bluetooth car command
		distance_check();
		
		if(get_button1())
		{
			PORTG = ~PORTG;
		}
	  
	}
}


void init_timer0() 
{
   TCNT0=6;   // TCNT 6~256 ==> 정확히 1ms 마다 TIMT 0 OVF INT 
   // 분주비를 64로 설정 P269 표13-1
   TCCR0 |= (1 << CS02) | (0 << CS01) | (0 << CS00);

   TIMSK |= (1 << TOIE0);         // 오버플로 인터럽트 허용
}
/*
	1.	LEFT MOTOR
		PORTF0 : IN1
		PORTF1 : IN2
	2.	RIGHT MOTOR
		PORTF2 : IN3
		PORTF3 : IN4
		IN1, IN2	IN3, IN4
		========	========
			0			1		역회전
			1			0		정회전
			1			1		정지
*/
#define MOTOR_DRIVER_PORT	PORTF
#define MOTOR_DRIVER_PORT_DDR	DDRF

#define MOTOR_DDR	DDRB
#define MOTOR_RIGH_PORT_DDR	PORTB5
#define MOTOR_LEFT_PORT_DDR PORTB6

void init_pwm_motor(void)
{
	MOTOR_DRIVER_PORT_DDR |= (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3);		// motor driver port
	MOTOR_DDR |= (1 << MOTOR_RIGH_PORT_DDR) | (1 << MOTOR_LEFT_PORT_DDR);	// pwm port
	
	TCCR1B |= ( 0 << CS12) | ( 1 << CS11) | (1 << CS10);   // 분주비 64
	// 1600000HZ / 64분주 ==> 250000HZ (250KHZ)
	// 256 / 250000 ==> 1.02ms	(펄스 256개 카운트 시간)
	// 127 / 250000 ==> 0.5ms
	// 0x3FF(1023) ==> 4ms
	TCCR1B |= (1 << WGM13) | (1 << WGM12);	//모드 14 고속 PWM ICR1
	TCCR1A |= (1 << WGM11) | (0 << WGM10);	//모드 14 고속 PWM ICR1
	TCCR1A |= (1 << COM1A1) | (0 << COM1A0); //비반전 모드 : OCR LOW TOP : HIGH
	TCCR1A |= (1 << COM1B1) | (0 << COM1B0); //비반전 모드 : OCR LOW TOP : HIGH
	
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3));
	MOTOR_DRIVER_PORT |= (1 << 2) | (1 << 0);	//자동차를 전진 모드로 SETTING
	
	
	ICR1=0x3FF;	// 4ms
}

void manual_mode_run(void)
{
	switch (UART1_RX_data)
	{
		case 'F':
			forward(700);	// 4us * 500 = 2ms
		break;
		
		case 'B':
		backward(700);
		break;
		
		case 'L':
		turn_left(700);
		break;
		
		case 'R':
		turn_right(700);
		break;
		
		case 'S':
		stop();
		break;
				
		default:
		break;
	}
}

void forward(int speed)
{
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3));
	MOTOR_DRIVER_PORT |= (1 << 0) | (1 << 2);	//자동차를 전진 모드로 SETTING
	
	if(speed >= 1023)
		speed = 1023;
	else if(speed <= 0)
		speed = 0;
		
	OCR1A = speed;	//	PB5 PWM 출력 RIGHT 
	OCR1B = speed;	//	PB6 PWM 출력 LEFT
}

void backward(int speed)
{
		MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3));
		MOTOR_DRIVER_PORT |= (1 << 1) | (1 << 3);	//자동차를 전진 모드로 SETTING
		
		if(speed >= 1023)
		speed = 1023;
		else if(speed <= 0)
		speed = 0;
		
		OCR1A = speed;	//	PB5 PWM 출력 RIGHT
		OCR1B = speed;	//	PB6 PWM 출력 LEFT
}

void turn_left(int speed)
{
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3));
	MOTOR_DRIVER_PORT |= (1 << 0) | (1 << 2);	//자동차를 전진 모드로 SETTING
	
	if(speed >= 1023)
	speed = 1023;
	else if(speed <= 0)
	speed = 0;
	
	OCR1A = speed;	//	PB5 PWM 출력 RIGHT
	OCR1B = 0;	//	PB6 PWM 출력 LEFT
}

void turn_right(int speed)
{
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3));
	MOTOR_DRIVER_PORT |= (1 << 0) | (1 << 2);	//자동차를 전진 모드로 SETTING
		
	if(speed >= 1023)
	speed = 1023;
	else if(speed <= 0)
	speed = 0;
		
	OCR1A = 0;	//	PB5 PWM 출력 RIGHT
	OCR1B = speed;	//	PB6 PWM 출력 LEFT
}

void stop()
{
	MOTOR_DRIVER_PORT &= ~((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3));
	//MOTOR_DRIVER_PORT |= (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3);	//자동차를 전진 모드로 SETTING

		
	OCR1A = 0;	//	PB5 PWM 출력 RIGHT
	OCR1B = 0;	//	PB6 PWM 출력 LEFT
}
﻿/*
 * uart0.c
 *
 * Created: 2022-08-09 오전 10:45:32
 *  Author: kccistc
 
 1. 전송속도 : 9600bps
 2. 비동기식, data 8bit, none parity
 3. rx(수신) Interrupt 활성화
 
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <string.h> // strncmp, strcpy

#include "uart0.h"
#include "led.h"

// UART0로부터 1btye가 들어오면 rx (수신) interrupt 발생되어 이곳으로 들어옴
ISR(USART0_RX_vect)
{
   unsigned char data;
   
   data = UDR0;   //uart0의 HW register(UDR0)로 1btye를 읽어 들임
   if (data == '\r' || data == '\n')   //문장의 끝이면
   {
      rx_buff[i] = '\0';   //문장의 끝을 가리키는 null 추가
      i = 0;
      //문제 : 새로운 메세지가 오면 덮어 씀
      //해결 : circular queue 로 개선해야 함
	  rx_ready_flag = 1; // 완전한 문장이 들어왔을 때 1로 set 된다
   }
   else
   {
      rx_buff[i++] = data;   //변수 저장후, i 값 증가
   }						 // 1. rx_buff[i] = data, 2. i++
}

void init_uart0(void)
{
   UBRR0H = 0x00;
   UBRR0L = 207;   //9600bps
   
   UCSR0A |= (1 << U2X0);   //2배속 통신
   UCSR0C |= 0x06;         //ASYNC(비동기식), data 8bit, none parity
   
   // RXEN0 : UART0로 부터 수신이 가능하도록 설정
   // TXEN0 : UART0로 부터 송신이 가능하도록 설정
   // RXCIE0 : UART0로부터 1byte가 들어오면 RX Interrupt 요청
   UCSR0B = (1 << RXEN0) | (1 << TXEN0) | (1 << RXCIE0);
}

//UART0로 1btye 보내는 함수
void UART0_transmit(uint8_t data)
{
   while ( !(UCSR0A & (1 << UDRE0))) //data가 전송 중이면 data가 다 전송될때까지 기다림
      ;   //no operation
   
   UDR0 = data;   //HW 전송 register에 data를 보냄
   
}

// 1. command를 함수화하여 led.c에 배치한다
// ledallon
// ledalloff
// ledalltoggle (on/off) : 300ms 주기로 led 전체를 on/off 반복한다

extern int led_command;
void pc_command_processing()
{
	if (rx_ready_flag)  // if (rx_ready_flag  >= 1) 
	{ 
		rx_ready_flag=0;
		 printf("%s\n", rx_buff);
		 
		 if (strncmp(rx_buff, "ledallon", strlen("ledallon")-1)== 0)  // compare(비교),  -1=null을 빼준다
			PORTA = 0xff;
		 if (strncmp(rx_buff, "ledalloff", strlen("ledalloff")-1)== 0)  // compare(비교),  -1=null을 빼준다
		    PORTA = 0x00;
		 if (strncmp(rx_buff, "ledreset", strlen("reset")-1)== 0)  // compare(비교),  -1=null을 빼준다
		    led_command=0;
		 if (strncmp(rx_buff, "ledalltoggle", strlen("ledalltoggle")-1)== 0)  // 
			led_command=1; 
		 if (strncmp(rx_buff, "shift_left_led_on", strlen("shift_left_led_on")-1)== 0)  //
			led_command=1;		
		 if (strncmp(rx_buff, "shift_right_led_on", strlen("shift_right_led_on")-1)== 0)  //
			led_command=2;
		 if (strncmp(rx_buff, "shift_left_hold_led_on", strlen("shift_left_hold_led_on")-1)== 0)  //
			led_command=3;
		 if (strncmp(rx_buff, "shift_right_hold_led_on", strlen("shift_right_hold_led_on")-1)== 0)  //
			led_command=4;
		 if (strncmp(rx_buff, "f_off", strlen("f_off")-1)== 0)  //
			led_command=5;
		 if (strncmp(rx_buff, "flower_on", strlen("flower_on")-1)== 0)  //
			led_command=6;
	}
	
		switch(led_command)
		{
			case 1:
				shift_left_led_on();
				break;
			case 2:
				shift_right_led_on();
				break;
			case 3:
				shift_left_hold_led_on();
				break;
			case 4:
				shift_right_hold_led_on();
				break;
			case 5:
				f_off();
				break;
			case 6:
				flower_on();
				break;
		}
}
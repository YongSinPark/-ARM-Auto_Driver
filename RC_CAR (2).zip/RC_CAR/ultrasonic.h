﻿/*
 * ultrasonic.h
 *
 * Created: 2022-08-10 오후 4:22:16
 *  Author: kcci
 */ 


#ifndef ULTRASONIC_H_
#define ULTRASONIC_H_
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define FALSE 0
#define TRUE  1

#define US_TCNT_LEFT  TCNT3		// timer3 16bit

#define TRIG_LEFT  0			// TRIGER PIN
#define TRIG_LEFT_DDR  DDRA
#define TRIG_LEFT_PORT PORTA

//	HW EXTERNAL INT 4 : PE4
#define ECHO_LEFT  4
#define ECHO_LEFT_DDR  DDRE
#define ECHO_LEFT_PIN  PINE 


#define US_TCNT_CENTER  TCNT3		// timer3 16bit

#define TRIG_CENTER  1			// TRIGER PIN
#define TRIG_CENTER_DDR  DDRA
#define TRIG_CENTER_PORT PORTA

//	HW EXTERNAL INT 5 : PE5
#define ECHO_CENTER  5
#define ECHO_CENTER_DDR  DDRE
#define ECHO_CENTER_PIN  PINE


#define US_TCNT_RIGHT  TCNT3		// timer3 16bit

#define TRIG_RIGHT  2			// TRIGER PIN
#define TRIG_RIGHT_DDR  DDRA
#define TRIG_RIGHT_PORT PORTA

//	HW EXTERNAL INT 6 : PE6
#define ECHO_RIGHT  6
#define ECHO_RIGHT_DDR  DDRE
#define ECHO_RIGHT_PIN  PINE

void init_ultrasonic();
void ultrasonic_trigger();
void distance_check();

extern volatile int ultrasonic_left_distance;
extern volatile int ultrasonic_center_distance;
extern volatile int ultrasonic_right_distance;

#endif /* ULTRASONIC_H_ */
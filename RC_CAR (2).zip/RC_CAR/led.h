﻿/*
 * led.h
 *
 * Created: 2022-08-09 오후 2:39:54
 *  Author: kccistc
 */ 


#ifndef LED_H_
#define LED_H_

void shift_left_led_on(void);
void shift_right_led_on(void);
void shift_left_hold_led_on(void);
void shift_right_hold_led_on(void);
void f_off(void);
void flower_on(void);
void init_led();

#endif /* LED_H_ */
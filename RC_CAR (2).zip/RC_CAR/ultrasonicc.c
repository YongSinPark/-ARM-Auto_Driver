﻿/*
 * ultrasonicc.c
 *
 * Created: 2022-08-10 오후 4:21:49
 *  Author: kcci
 */ 
#include "ultrasonic.h"

volatile int ultrasonic_left_distance = 0;
volatile int ultrasonic_center_distance = 0;
volatile int ultrasonic_right_distance = 0;
char scm[50];  
// 왼쪽 초음파 PE4 : 외부 INT4 초음파 센서 상승.하강 에지 둘다 이쪽으로 들어 온다.
// 초음파 : 1cms를 이동하는데 29us 소요 1cm왕복 : 29 * 2 = 58us 소요
// 16khz / 1024 == 15625hz
// t = 1/f => 6.4us 
ISR(INT4_vect)
{
	if (ECHO_LEFT_PIN & (1 << ECHO_LEFT))   // 상승 에지
	{
		TCNT3 = 0;
	}
	else   // 하강 에지 
	{
		// 에코핀의 펄스 길이를  us단위로 환산
		ultrasonic_left_distance = (1000000.0 * TCNT3 * 1024 / F_CPU) / 58; // cm로 환산	
		// 1cm : 58us소요 
	}
}
//center
ISR(INT5_vect)
{
	if (ECHO_CENTER_PIN & (1 << ECHO_CENTER))   // 상승 에지
	{
		TCNT3 = 0;
	}
	else   // 하강 에지
	{
		// 에코핀의 펄스 길이를  us단위로 환산
		ultrasonic_center_distance = (1000000.0 * TCNT3 * 1024 / F_CPU) / 58; // cm로 환산
		// 1cm : 58us소요
	}
}

//right
ISR(INT6_vect)
{
	if (ECHO_RIGHT_PIN & (1 << ECHO_RIGHT))   // 상승 에지
	{
		TCNT3 = 0;
	}
	else   // 하강 에지
	{
		// 에코핀의 펄스 길이를  us단위로 환산
		ultrasonic_right_distance = (1000000.0 * TCNT3 * 1024 / F_CPU) / 58; // cm로 환산
		// 1cm : 58us소요
	}
}
 // PG4 :trigger
 // PE4 : echo (INT4) 외부 인터럽트 4번 
 void init_ultrasonic()
 {
	 //LEFT
	 TRIG_LEFT_DDR |= (1 << TRIG_LEFT);   // output mode로 설정 
	 ECHO_LEFT_DDR &= ~(1 << ECHO_LEFT);  // input mode로 설정
	 
	 //EICRA : INT 0~3
	 //EICRB : INT 4~7
	 // 0 1 : 어떠한 형태로든지 신호 변화가 발생 되면 INT 요청 (상승.하강에지 둘다 INT)
	 EICRB |= (0 << ISC41) | (1 << ISC40);
	 TCCR3B |= (1 << CS32) | (1 << CS30);   // 1024분주 
	 // 16비트 timer 1번을 1024분주 해서 공급
	 // 16MHZ 를 1024분주 --> 16000000/1024 ==> 15625HZ ==> 15.625KHZ
	 // 1펄스의 길이 : t = 1/f  1/15625 = 0.000064sec ==> 64us
	 
	 EIMSK |= (1 << INT4);   // 외부 INT4(ECHO) 사용 
	 
	 
	//CENTER
	TRIG_CENTER_DDR |= (1 << TRIG_CENTER);   // output mode로 설정
	ECHO_CENTER_DDR &= ~(1 << ECHO_CENTER);  // input mode로 설정
	 	 
	//EICRA : INT 0~3
	//EICRB : INT 4~7
	// 0 1 : 어떠한 형태로든지 신호 변화가 발생 되면 INT 요청 (상승.하강에지 둘다 INT)
	EICRB |= (0 << ISC51) | (1 << ISC50);
	TCCR3B |= (1 << CS32) | (1 << CS30);   // 1024분주
	// 16비트 timer 1번을 1024분주 해서 공급
	// 16MHZ 를 1024분주 --> 16000000/1024 ==> 15625HZ ==> 15.625KHZ
	// 1펄스의 길이 : t = 1/f  1/15625 = 0.000064sec ==> 64us
	 	 
	EIMSK |= (1 << INT5);   // 외부 INT4(ECHO) 사용
	 
	 
	//RIGHT
	TRIG_RIGHT_DDR |= (1 << TRIG_RIGHT);   // output mode로 설정
	ECHO_RIGHT_DDR &= ~(1 << ECHO_RIGHT);  // input mode로 설정
	 	
	//EICRA : INT 0~3
	//EICRB : INT 4~7
	// 0 1 : 어떠한 형태로든지 신호 변화가 발생 되면 INT 요청 (상승.하강에지 둘다 INT)
	EICRB |= (0 << ISC61) | (1 << ISC60);
	TCCR3B |= (1 << CS32) | (1 << CS30);   // 1024분주
	// 16비트 timer 1번을 1024분주 해서 공급
	// 16MHZ 를 1024분주 --> 16000000/1024 ==> 15625HZ ==> 15.625KHZ
	// 1펄스의 길이 : t = 1/f  1/15625 = 0.000064sec ==> 64us
	 	
	EIMSK |= (1 << INT6);   // 외부 INT4(ECHO) 사용
	 
 }
 void ultrasonic_trigger()
 {
	 //LEFT
	 TRIG_LEFT_PORT &= ~(1 << TRIG_LEFT);  // LOW
	 _delay_us(1);
	 TRIG_LEFT_PORT |= (1 << TRIG_LEFT);  // 1: HIGH 
	 _delay_us(15); 
	 TRIG_LEFT_PORT &= ~(1 << TRIG_LEFT);  // LOW
	 
	 _delay_ms(50); // 초음파 센서 echo응답 시간 최대 38ms
					// delay를 timer int처리
					
	//CENTER
	TRIG_CENTER_PORT &= ~(1 << TRIG_CENTER);  // LOW
	_delay_us(1);
	TRIG_CENTER_PORT |= (1 << TRIG_CENTER);  // 1: HIGH
	_delay_us(15);
	TRIG_CENTER_PORT &= ~(1 << TRIG_CENTER);  // LOW
		 
	_delay_ms(50); // 초음파 센서 echo응답 시간 최대 38ms
	// delay를 timer int처리
	
	
	//RIGHT
	TRIG_RIGHT_PORT &= ~(1 << TRIG_RIGHT);  // LOW
	_delay_us(1);
	TRIG_RIGHT_PORT |= (1 << TRIG_RIGHT);  // 1: HIGH
	_delay_us(15);
	TRIG_RIGHT_PORT &= ~(1 << TRIG_RIGHT);  // LOW
	
	_delay_ms(50); // 초음파 센서 echo응답 시간 최대 38ms
	// delay를 timer int처리
 }
 
 void distance_check()
 {
	 ultrasonic_trigger();
	 
	 printf("left : %dcm\n", ultrasonic_left_distance);
	 printf("center : %dcm\n", ultrasonic_center_distance);
	 printf("right : %dcm\n", ultrasonic_right_distance);
 }
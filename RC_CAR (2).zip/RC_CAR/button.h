﻿/*
 * button.h
 *
 * Created: 2022-08-04 오후 4:08:47
 *  Author: kcci
 */ 


#ifndef BUTTON_H_
#define BUTTON_H_
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

#define BUTTON_DDR	DDRC
#define BUTTON_PIN  PINC  // PortB를 read를 하는 register
#define BUTTON1		7    // PORTB.7

int get_button1();

#endif /* BUTTON_H_ */